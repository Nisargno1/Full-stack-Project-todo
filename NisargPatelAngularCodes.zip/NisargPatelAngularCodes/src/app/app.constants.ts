
export const TODO_JPA_API = "http://localhost:8080/jpa"